<template>
<header>
    <nav>
        <ul>
            <li>Home</li>
            <li>Sobre</li>
            <li>Contato</li>
        </ul>
    </nav>
</header>
</template>

<script>
export default {
    name: 'NavPage'
}
</script>

<style>

</style>