<template>
<section>
    <div>
        <p>Menu conteúdo</p>
        <div>
            <!--VMODEL-->
            <input v-model="name" placeholder="Digite seu nome">
            <p>Seu nome é: {{ name }}</p>
            <!--V-CLICK-->
            <button @click="submeterFormulario">Procurar usuário</button>
            <!--V-If e V-Else -->
            <p v-if="url">
                    {{ url }}
            </p>
            <p v-else>
                Você ainda não buscou usuários
            </p>
        </div>
    </div>
</section>
</template>

<script>

export default{
    name: 'ContentPage',
    data() {
        return {
            name: '',
            url: ''
        }
    },
    methods: {
        submeterFormulario() {
           fetch(`https://api.github.com/users/${this.name}`).then((data) => {
               this.url = data.url;
               console.log(data.url)
            });
        }
    }
}
</script>

<style>

</style>