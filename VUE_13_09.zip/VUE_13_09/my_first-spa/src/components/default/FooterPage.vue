<template>
<footer>
    <p>&copy; 2024 Etec JK</p>
</footer>
</template>

<script>
export default {
    name: 'FooterPage'
}
</script>

<style>

</style>